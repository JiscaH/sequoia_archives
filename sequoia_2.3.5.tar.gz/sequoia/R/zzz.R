
#.onUnload <- function (libpath) {
#  .Fortran("deallocall", PACKAGE = "sequoia")
#  library.dynam.unload("sequoia", libpath)
#}
