#' @title Find putative relatives
#'
#' @description Identify pairs of individuals likely to be related, but not
#'   assigned as such in the provided pedigree.
#'
#' @param GenoM matrix with genotype data, size nInd x nSnp
#' @param SeqList list with output from \code{\link{sequoia}}. If provided, the
#' elements `Specs', `AgePriors' and 'LifeHist' are used, and all other input
#' parameters except 'GenoM', 'ParSib' and 'quiet' are ignored.
#' @param Ped dataframe with pedigree, with id - dam - sire in columns 1-3
#' @param LifeHistData dataframe with columns id - sex (1=female, 2=male,
#'   3=unknown) - birth year
#' @param ParSib either 'par' to check for putative parent-offspring pairs only,
#'   or 'sib' to check for all types of first and second degree relatives. When
#'   'par', all pairs are returned that are more likely parent-offspring than
#'   unrelated, including pairs that are even more likely to be otherwise
#'   related.
#' @param Complex either "full" (default), "simp" (simplified, no explicit
#'   consideration of inbred relationships), "mono" (monogamous) or "herm"
#'   (hermaphrodites, otherwise like "full").
#' @param Err estimated genotyping error rate. The error model aims to deal with
#'   scoring errors typical for SNP arrays.
#' @param MaxMismatch maximum number of loci at which candidate parent and
#'   offspring are allowed to be opposite homozygotes. Setting a more liberal
#'   threshold can improve performance if the error rate is high, at the cost of
#'   decreased speed.
#' @param Tassign minimum LLR required for acceptance of proposed relationship,
#'   relative to next most likely relationship. Higher values result in more
#'   conservative assignments. Must be zero or positive.
#' @param MaxPairs  The maximum number of putative pairs to return.
#' @param DumPrefix  character vector of length 2 with prefixes for dummy dams
#'   (mothers) and sires (fathers) used in \code{Ped}.
#' @param quiet suppress messages
#'
#' @return A list with
#'   \item{MaybeParent or MaybeRel}{Non-assigned likely relatives}
#'   \item{MaybeTrio}{Non-assigned parent-parent-offspring trios}
#'
#' @examples
#' \dontrun{
#' data(SimGeno_example, LH_HSg5, package="sequoia")
#' SeqOUT <- sequoia(GenoM = SimGeno_example,
#'                   LifeHistData = LH_HSg5, MaxSibIter = 0)
#' MaybePO <- GetMaybeRel(GenoM = SimGeno_example,
#'                       SeqList = SeqOUT)
#'
#' # age differences limit which relationships are considered:
#' MaybePO3 <- GetMaybeRel(GenoM = SimGeno_example,
#'                       Ped = SeqOUT$PedigreePar)
#' }
#'
#' @useDynLib sequoia, .registration = TRUE
#'
#' @export

GetMaybeRel <- function(GenoM = NULL,
                        SeqList = NULL,
                        Ped = NULL,
                        LifeHistData = NULL,
                        ParSib = "par",
                        Complex = "full",
                        Err = 0.0001,
                        MaxMismatch = 3,
                        Tassign = 0.5,
                        MaxPairs =  7*nrow(GenoM),
                        DumPrefix = c("F0", "M0"),
                        quiet = FALSE)
{
  on.exit(.Fortran("deallocall"), add=TRUE)

  # input check
	Excl <- CheckGeno(GenoM, quiet=quiet)
	if (ParSib == "full") ParSib <- "sib"
  if (!ParSib %in% c("par", "sib"))  stop("Invalid value for 'ParSib', choose 'par' or 'sib'")
	if (nchar(DumPrefix[1]) != nchar(DumPrefix[2])) stop("DumPrefix must have same number of characters")

	gID <- rownames(GenoM)
  GenoV <- as.integer(GenoM)

  if ("Pedigree" %in% names(SeqList)) {
    Ped <- SeqList$Pedigree
  } else if ("PedigreePar" %in% names(SeqList)) {
    Ped <- SeqList$PedigreePar
  }
  if (!is.null(Ped)) {
    Ped <- PedPolish(Ped, GenoNames = rownames(GenoM), NAToZero = TRUE)
    DPnc <- nchar(DumPrefix)[1]
    PedNum <- IDToNum(Ped[,1:3], gID, DumPrefix)
    PedPar <- as.matrix(PedNum[gID, 2:3])   # not dummy indivs
    PedPar[is.na(PedPar)] <- 0   # in case not all genotyped indivs in Ped
  } else {
    PedPar <- rep(0, 2*nrow(GenoM))
  }

  PrSb <- switch(ParSib, dup=0, par = 1, sib = 2)
  nAmbMax <- MaxPairs  # max no. of non-assigned relative pairs to return

  if ("Specs" %in% names(SeqList)) {
    Specs <- SeqList$Specs
    LhIN <- SeqList$LifeHist
    Ng <- FacToNum(Specs[,"NumberIndivGenotyped"])
		SMax <- FacToNum(Specs[,"MaxSibshipSize"])

    Cmplx <- switch(Specs[,"Complexity"], full = 2, simp = 1, mono = 0, herm = 4)
    UAge <- switch(Specs[,"UseAge"], extra = 2, yes = 1, no = 0)
		AP <- SeqList$AgePriors[, c("MS", "PS", "MGM", "PGF", "MGF", "UA", "M", "P", "FS")]
    SpecsInt <- c(ParSib = as.integer(PrSb),        		  	 # 1
									MaxSibIter = as.integer(-1),							 # 2
                  nSnp = FacToNum(Specs[,"NumberSnps"]),     # 3
                  MaxMis = FacToNum(Specs[,"MaxMismatch"]),  # 4
									SMax = SMax,                               # 5
                  nAgeCl = FacToNum(Specs[,"nAgeClasses"]),  # 6
                  Complx = as.integer(Cmplx),                # 7
									FindMaybe = as.integer(1),        # 8
									CalcLLR = as.integer(0),          # 9
                  quiet = as.integer(quiet),        # 10
									nAmbMax = as.integer(nAmbMax),    # 11
                  UseAge = as.integer(UAge))        # 12
    SpecsDbl <- c(Er = FacToNum(Specs[,"GenotypingErrorRate"]),
                  TF = FacToNum(Specs[,"Tfilter"]),
                  TA = FacToNum(Specs[,"Tassign"]))

  } else {
    Ng <- nrow(GenoM)
    LhIN <- LifeHistData
    if (!is.null(LhIN))   names(LhIN) <- c("ID", "Sex", "BY")
		if (is.null(Ped)) {
			SMax <- 100
		} else {
			SMax <- max(table(Ped$dam), table(Ped$sire)) +1
		}
    Cmplx <- switch(Complex, full = 2, simp = 1, mono = 0, herm = 4)
    if (!is.null(Ped) & !is.null(LifeHistData)) {
      AP <- MakeAgePrior(Ped, LifeHistData, Plot=FALSE, quiet=TRUE)
      UseAge <- 1
    } else {
		  AP <- matrix(1, nrow=3, ncol=9)
		  UseAge <- 0
    }
    SpecsInt <- c(ParSib = as.integer(PrSb),            # 1
									MaxSibIter = as.integer(-1),				  # 2
                  nSnp = as.integer(ncol(GenoM)),       # 3
                  MaxMis = as.integer(MaxMismatch),     # 4
									SMax = SMax,                          # 5
                  nAgeCl = as.integer(nrow(AP)),        # 6
                  Complx = as.integer(Cmplx),           # 7
									FindMaybe = as.integer(1),            # 8
									CalcLLR = as.integer(0),          		# 9
                  quiet = as.integer(quiet),      		  # 10
									nAmbMax = as.integer(nAmbMax),        # 11
                  UseAge = as.integer(UseAge))       				# 12
    SpecsDbl <- c(Er = as.double(Err),
                  TF = as.double(2.0),   # not used
                  TA = as.double(Tassign))
  }

	# Dummies
  Nd <- 0
  DumParRF <- rep(0, 4*as.integer(Ng/2))
  dID <- NULL
  if (!is.null(Ped)) {
    Nd <- c(sum(substr(Ped$id,1,DPnc)==DumPrefix[1]),
            sum(substr(Ped$id,1,DPnc)==DumPrefix[2]))
    if (max(Nd)>0) {
      SibshipGPs <- array(0, dim=c(2,max(Nd),2),
                          dimnames=list(c("grandma", "granddad"), 1:max(Nd), c("mat", "pat")))
      for (k in 1:2) {
        SibshipGPs[,1:Nd[k],k] <- t(as.matrix(PedNum[substr(Ped$id,1,DPnc)==DumPrefix[k], 2:3]))
      }
      for (k in 1:2) {
        for (s in 1:Nd[k]) {
          for (g in 1:2) {
            x <- (k-1)*2*as.integer(Ng/2) + (s-1)*2 + g
            DumParRF[x] <- SibshipGPs[g,s,k]
          }
        }
      }
      dID <- c(Ped$id[substr(Ped$id,1,DPnc)==DumPrefix[1]],
               Ped$id[substr(Ped$id,1,DPnc)==DumPrefix[2]])
    }
  }

  LHL <- orderLH(LhIN[LhIN$Sex %in% c(1:3), ], gID)

  #=========================
	# call fortran
  TMP <- .Fortran("FindAmbig",
                  Ng = as.integer(Ng),
                  SpecsInt = as.integer(SpecsInt),
                  SpecsDbl = as.double(SpecsDbl),
                  GenoV = as.integer(GenoV),
									Sex = as.integer(LHL$Sex),
                  BY = as.integer(LHL$BY),
									AP = as.double(AP),
									ParentsRF = as.integer(PedPar),
#									Nd = as.integer(Nd),
                  DumParRF = as.integer(DumParRF),

									nAmb = as.integer(0),
                  AmbigID = integer(2*nAmbMax),
                  AmbigRel = integer(2*nAmbMax),
                  AmbigLR = double(2*nAmbMax),
                  AmbigOH = integer(nAmbMax),

									nTrio = as.integer(0),
                  trioID = integer(3*Ng),
                  trioLR = double(3*Ng),
                  trioOH = integer(3*Ng))

	TMP$AmbigLR[abs(TMP$AmbigLR - 999) < 0.1] <- NA
  TMP$AmbigLR <- round(TMP$AmbigLR, 2)
  TMP$AmbigOH[TMP$AmbigOH < 0] <- NA
  TMP$trioLR[abs(TMP$trioLR - 999) < 0.1] <- NA
  TMP$trioLR <- round(TMP$trioLR, 2)
  TMP$trioOH[TMP$trioOH < 0] <- NA

  #=========================
  # non-assigned probable relative pairs

	# TODO: look up sex & agedif if LH provided.

  if (TMP$nAmb > 0) {
    RelName <- c("PO", "FS", "HS", "GP", "FA", "HA", "U ", "XX", "2nd")
    Na <- TMP$nAmb
    TMP$AmbigID <- NumToID(TMP$AmbigID, 0, gID, dID)
    AmbigRel <- factor(TMP$AmbigRel, levels=1:9, labels=RelName)

    MaybeRel <- data.frame(VtoM(TMP$AmbigID, Na),
                           VtoM(AmbigRel, Na),
                           VtoM(TMP$AmbigLR, Na),
                           stringsAsFactors=FALSE)
    names(MaybeRel) <- c("ID1", "ID2", "Relx", "TopRel", "LLR_Rx_U", "LLR")
    MaybeRel <- MaybeRel[,-which(names(MaybeRel) %in% c("Relx", "LLR_Rx_U"))]  # drop; confusing.
    MaybeRel$OH <-  TMP$AmbigOH[s(Na)]

    if (!is.null(LhIN) & nrow(MaybeRel)>0) {
      LhIN$BY[LhIN$BY<0] <- NA
      MaybeRel <- merge(MaybeRel, setNames(LhIN, c("ID1","Sex1","BY1")), all.x=TRUE)
      MaybeRel <- merge(MaybeRel, setNames(LhIN, c("ID2","Sex2","BY2")), all.x=TRUE)
      MaybeRel$AgeDif <- with(MaybeRel, BY1 - BY2)
      MaybeRel <- MaybeRel[, c("ID1", "ID2", "TopRel", "LLR", "OH",
                               "BY1", "BY2", "AgeDif", "Sex1", "Sex2")]
      for (i in 1:Na) {
        if (is.na(MaybeRel$AgeDif[i]))  next
        if (MaybeRel$AgeDif[i] < 0) {
          tmp <- MaybeRel[i,]
          tmp$AgeDif <- abs(tmp$AgeDif)
          MaybeRel[i,] <- tmp[,c("ID2","ID1","TopRel", "LLR", "OH",
                                 "BY2", "BY1","AgeDif", "Sex2", "Sex1")]
        }
      }
    }

    if (grepl("sib", ParSib)) {
      MaybeRel <- with(MaybeRel, MaybeRel[TopRel %in% c("PO", "FS", "HS","GG") |
                                          LLR > FacToNum(Specs[,"Tassign"]), ])
    }
    MaybeRel <- MaybeRel[order(ordered(MaybeRel$TopRel, levels=RelName),
                                     -MaybeRel$LLR),]

    if (any(LhIN$Sex==4)) {  # hermaphrodites
      MaybeRel <- herm_unclone_MaybeRel(MaybeRel, Ped[,1:3], LH=LhIN, herm.suf=c("f", "m"))
    }

    if (quiet<1 && nrow(MaybeRel)>0) {
      if (grepl("par", ParSib)) {
        message("there are  ", sum(MaybeRel$TopRel=="PO"),
             "  likely parent-offspring pairs and ", nrow(MaybeRel)-sum(MaybeRel$TopRel=="PO"),
             " other pairs of likely relatives  which are not assigned, ",
             "perhaps due to unknown birth year(s)")
      } else {
        message("there are  ", nrow(MaybeRel), "  non-assigned pairs of possible relatives, ",
               "including  ", sum(MaybeRel$TopRel=="PO"), "  likely parent-offspring pairs")
      }
    }
    if (nrow(MaybeRel)==0) {
      MaybeRel <- NULL
    } else {
      rownames(MaybeRel) <- 1:nrow(MaybeRel)
    }
  } else  MaybeRel <- NULL


  #=========================
  # non-assigned parent-parent-offspring trios
  if (TMP$nTrio>0) {
    trios <- data.frame(VtoM(TMP$trioID, nr=TMP$nTrio, nc=3),
                         VtoM(TMP$trioLR, nr=TMP$nTrio, nc=3),
                        VtoM(TMP$trioOH, nr=TMP$nTrio, nc=3),
                         stringsAsFactors=FALSE)
    names(trios) <- c("id", "parent1", "parent2", "LLRparent1", "LLRparent2", "LLRpair",
                      "OHparent1", "OHparent2", "MEpair")
    for (k in 1:3) trios[, k] <- NumToID(trios[, k], k-1, gID, dID)

    if (any(LhIN$Sex==4)) {  # hermaphrodites
      trios <- herm_unclone_Trios(trios, LH=LhIN, herm.suf=c("f", "m"))
    }

    if (quiet<1) {
      message("found ", nrow(trios), " parent-parent-offspring trios with parents of unknown sex")
    }
  } else  trios <- NULL

  if (grepl("par", ParSib)) {
    return( list(MaybePar = MaybeRel,
               MaybeTrio = trios) )
  } else {
    return( list(MaybeRel = MaybeRel,
               MaybeTrio = trios) )
  }
}
