#============================================================================
#' @title Comparison of all pairwise relationships in 2 pedigrees
#'
#' @description Compare, count and identify different types of relative pairs
#'   between two pedigrees. The matrix returned by \code{\link{DyadCompare}}
#'   [Deprecated] is a subset of the matrix returned here using default
#'   settings.
#'
#' @param Ped1 Original pedigree, dataframe with 3 columns: id-dam-sire
#' @param Ped2 Second (inferred) pedigree
#' @param GenBack  Number of generations back to consider; 1 returns
#'   parent-offspring and sibling relationships, 2 also returns grandparental,
#'   avuncular and first cousins. GenBack >2 is not implemented.
#' @param patmat  logical, distinguish between paternal versus maternal relative
#'   pairs?
#' @param DumPrefix character vector of length 2 with the dummy prefices in Ped1
#'   and/or Ped2. IDs starting with these prefices will not be excluded, but
#'   individuals with dummy parents are compared. Use \code{\link{GetRelCat}} on
#'   a single pedigree to find relationships with dummies.
#' @param Return  Return a matrix with \code{counts}, or detailed results as a
#'   2xNxN \code{array} or as a \code{dataframe}.
#'
#' @return a matrix with counts, a 3D array or a 4-column dataframe, depending
#'   on \code{Return}, with by default (\code{GenBack=1, patmat=FALSE}) the
#'   following 7 relationships:
#'    \item{S}{Self (not in counts)}
#'    \item{MP}{Parent}
#'    \item{O}{Offspring (not in counts)}
#'    \item{FS}{Full sibling}
#'    \item{HS}{Half sibling}
#'    \item{U}{Unrelated, or otherwise related}
#'    \item{X}{Either or both individuals not occuring in both pedigrees}
#' Where in the array and dataframe, 'MP' indicates that the second (column)
#' individual is the parent of the first (row) individual, and 'O' indicates the
#' reverse.
#'
#' When \code{GenBack=2, patmat=TRUE}, the following relationships are
#' distinguished:
#'    \item{S}{Self (not in counts)}
#'    \item{M}{Mother}
#'    \item{P}{Father}
#'    \item{O}{Offspring (not in counts)}
#'    \item{FS}{Full sibling}
#'    \item{MHS}{Maternal half-sibling}
#'    \item{PHS}{Paternal half-sibling}
#'    \item{MGM}{Maternal grandmother}
#'    \item{MGF}{Maternal grandfather}
#'    \item{PGM}{Paternal grandmother}
#'    \item{PGF}{Paternal grandfather}
#'    \item{GO}{Grand-offspring (not in counts}
#'    \item{FA}{Full avuncular; maternal or paternal aunt or uncle}
#'    \item{HA}{Half avuncular}
#'    \item{FN}{Full nephew/niece (not in counts}
#'    \item{HN}{Half nephew/niece (not in counts}
#'    \item{FC1}{Full first cousin}
#'    \item{DFC1}{Double full first cousin}
#'    \item{U}{Unrelated, or otherwise related}
#'    \item{X}{Either or both individuals not occuring in both pedigrees}
#' Note that for avuncular and cousin relationships no distinction is made
#' between paternal versus maternal, as this may differ between the two
#' individuals and would generate a large number of subclasses. When a pair is
#' related via multiple paths, the first-listed relationship is returned.
#'
#' When \code{GenBack=1, patmat=TRUE} the categories are (S)-M-P-(O)-FS-MHS-PHS-
#' U-X. When \code{GenBack=2, patmat=FALSE}, MGM, MGF, PGM and PGF are combined
#' into GP, with the rest of the categories analogous to the above.
#'
#' Note that in the dataframe each pair is listed twice, e.g. once as P and once
#' as O, or twice as FS.
#'
#' When \code{Return = "counts"} (the default), a matrix with counts is
#' returned, with the classification in Ped1 on rows and that in Ped2 in
#' columns. Counts for 'symmetrical' pairs ("FS", "HS", "MHS", "PHS", "FC1",
#' "DFC1", "U","X") are divided by two.
#'
#' When \code{Return = "array"}, the first dimension is 1=Ped1, 2=Ped2,
#' the 2nd and 3rd dimension are the two individuals of the pair.
#'
#' When \code{Return = "dataframe"}, the columns are
#'   \item{id.A}{First individual of the pair}
#'   \item{id.B}{Second individual of the pair}
#'   \item{RC1}{the relationship category in Ped1, as a factor with all
#'     considered categories as levels, including those with 0 count}
#'   \item{RC2}{the relationship category in Ped2}
#'
#'
#' @seealso \code{\link{PedCompare}} for individual-based comparison;
#'   \code{\link{GetRelCat}} for pairs of relatives within a single pedigree.
#'
#'
#' @examples
#' \dontrun{
#' data(Ped_HSg5, SimGeno_example, LH_HSg5, package="sequoia")
#' SeqOUT <- sequoia(GenoM = SimGeno_example, LifeHistData = LH_HSg5,
#'                   MaxSibIter = 0)
#' ComparePairs(Ped1=Ped_HSg5, Ped2=SeqOUT$Pedigree, Return="counts")
#' # matrix with counts of pairs
#' RC.A <- ComparePairs(Ped1=Ped_HSg5, Ped2=SeqOUT$Pedigree, Return="array")
#' RC.A[, "a05017", "b05018"] # check specific pairs
#'
#' RC.DF <- ComparePairs(Ped1=Ped_HSg5, Ped2=SeqOUT$Pedigree,
#'   Return="dataframe")
#' RC.DF[RC.DF$id.A=="a05017" & RC.DF$id.B=="b05018", ] # check specific pairs
#' table(RC.DF$Ped1, RC.DF$Ped2)
#' # incl. S,O,GO,FN,HN; duplicated counts for FS,HS,FC1,DFC1,U,X
#' Mismatches <- RC.DF[RC.DF$Ped1 != RC.DF$Ped2, ]
#' }
#' @export

ComparePairs <- function(Ped1 = NULL,
                         Ped2 = NULL,
                         GenBack = 1,
                         patmat = FALSE,
                         DumPrefix = c("F0", "M0"),
                         Return = "counts")
{
  if(is.null(Ped1)) stop("No 'Ped1' provided")
  if(is.null(Ped2)) stop("No 'Ped2' provided'")
	if (!Return %in% c("array", "counts", "dataframe"))  stop("'Return' must be 'counts', 'array', or 'dataframe'")
  if (!GenBack %in% 1:2)  stop("'GenBack' must be 1 or 2")
  if (!patmat %in% c(TRUE,FALSE))  stop("'patmat' must be TRUE or FALSE")

  Ped1 <- PedPolish(Ped1[,1:3], ZeroToNA=TRUE)
  Ped2 <- PedPolish(Ped2[,1:3], ZeroToNA=TRUE)
  if (!any(Ped2$id %in% Ped1$id))  stop("no common IDs in Ped1 and Ped2")

	RCM.1 <- t(sapply(1:nrow(Ped1), GetRelCat, Ped1, GenBack=GenBack, patmat=patmat))
	RCM.2 <- t(sapply(1:nrow(Ped2), GetRelCat, Ped2, GenBack=GenBack, patmat=patmat))
	rownames(RCM.1) <- colnames(RCM.1)
	rownames(RCM.2) <- colnames(RCM.2)

	# align the two matrices into an array
	IDs <- unique(c(Ped1$id, Ped2$id))
	RCA <- array(dim=c(2, length(IDs), length(IDs)),
							 dimnames=list(c("Ped1", "Ped2"), IDs, IDs))
	RCA["Ped1", Ped1$id, Ped1$id] <- RCM.1
	RCA["Ped2", Ped2$id, Ped2$id] <- RCM.2
	RCA[is.na(RCA)] <- "X"

	# delete dummies (doing this earlier may cause trouble with 2-generations-back GetRelCat)
	DPnc <- nchar(DumPrefix)
	Dummies <- substr(IDs,1,DPnc[1])==DumPrefix[1] | substr(IDs,1,DPnc[2])==DumPrefix[2]
	if (sum(Dummies)>0) {
	  RCA <- RCA[, !Dummies, !Dummies]
	  IDs <- IDs[!Dummies]
	}

	if (Return == "array") {
		return( RCA )

	} else if (Return == "counts") {
	  lvls.tbl <- list(GB1 = list(no = c("MP", "FS", "HS", "U", "X"),
	                              yes = c("M", "P", "FS", "MHS", "PHS", "U", "X")),
	                   GB2 = list(no = c("MP", "FS", "HS", "GP", "FA", "HA", "FC1", "DFC1", "U", "X"),
	                              yes = c("M", "P", "FS", "MHS", "PHS","MGM", "MGF", "PGM", "PGF",
	                                      "FA", "HA","FC1", "DFC1", "U", "X")))

	  tbl <- table(factor(RCA["Ped1",,], levels=lvls.tbl[[GenBack]][[ifelse(patmat, "yes", "no")]]),
	               factor(RCA["Ped2",,], levels=lvls.tbl[[GenBack]][[ifelse(patmat, "yes", "no")]]))

	  dup <- c("FS", "HS", "MHS", "PHS", "FC1", "DFC1", "U","X")   # pairs included double
	  these.dup <- rownames(tbl) %in% dup
	  tbl[these.dup, these.dup] <- tbl[these.dup, these.dup]/2
	  return( tbl )

	} else if (Return == "dataframe") {
	  lvls.df <- list(GB1 = list(no = c("S", "MP", "O", "FS", "HS", "U", "X"),
	                              yes = c("S","M", "P", "O", "FS", "MHS", "PHS", "U", "X")),
	                   GB2 = list(no = c("S","MP", "O", "FS", "HS", "GP", "GO", "FA", "HA", "FC1", "DFC1", "U", "X"),
	                              yes = c("S","M", "P", "O", "FS", "MHS", "PHS","MGM", "MGF", "PGM", "PGF", "GO",
	                                      "FA", "FN", "HA", "HN", "FC1", "DFC1", "U", "X")))
	  DF <- data.frame(id.A = rep(IDs, times=length(IDs)),
	                   id.B = rep(IDs, each=length(IDs)),
	                   Ped1 = factor(RCA["Ped1",,],
	                                 levels=lvls.df[[GenBack]][[ifelse(patmat, "yes", "no")]]),
	                   Ped2 = factor(RCA["Ped2",,],
	                                 levels=lvls.df[[GenBack]][[ifelse(patmat, "yes", "no")]]))
	  return( DF )
	}
}


#============================================================================
#============================================================================
#' @title Compare dyads
#'
#' @description Count the number of half and full sibling pairs correctly and
#'   incorrectly assigned. DEPRECATED - SEE \code{\link{ComparePairs}}
#'
#' @param  Ped1 Original pedigree, dataframe with 3 columns: id-dam-sire
#' @param  Ped2 Second (inferred) pedigree
#' @param  na1  the value for missing parents in Ped1.
#'
#' @return A 3x3 table with the number of pairs assigned as full siblings (FS),
#'   half siblings (HS) or unrelated (U, including otherwise related) in the two
#'   pedigrees, with the classification in Ped1 on rows and that in Ped2 in
#'   columns
#'
#' @seealso \code{\link{PedCompare}}
#'
#' @examples
#' \dontrun{
#' data(Ped_HSg5, SimGeno_example, LH_HSg5, package="sequoia")
#' SeqOUT <- sequoia(GenoM = SimGeno_example, LifeHistData = LH_HSg5,
#'                   MaxSibIter = 0)
#' DyadCompare(Ped1=Ped_HSg5, Ped2=SeqOUT$Pedigree)
#' }
#'
#' @export

DyadCompare <- function(Ped1 = NULL,
                       Ped2 = NULL,
                       na1 = c(NA, "0"))
{
  message("This function is deprecated, please use ComparePairs()")
  if(is.null(Ped1)) stop("No 'Ped1' provided")
  if(is.null(Ped2)) stop("No 'Ped2' provided'")
  names(Ped1)[1:3] <- c("id", "dam.1", "sire.1")
  names(Ped2)[1:3] <- c("id", "dam.2", "sire.2")
  for (i in 1:3) {
    Ped1[, i] <- as.character(Ped1[, i])
    Ped1[Ped1[, i] %in% na1, i] <- NA
  }
  for (i in 1:3) Ped2[, i] <- as.character(Ped2[, i])
  if (!any(Ped2$id %in% Ped1$id))  stop("no common IDs in Ped1 and Ped2")
  Ped1 <- Ped1[!is.na(Ped1$id), 1:3]
  Ped2 <- Ped2[!is.na(Ped2$id), 1:3]
  Ped1 <- PedPolish(Ped1)
  Ped2 <- PedPolish(Ped2)

  # note: each pair is counted double
  RCT <- matrix(NA, 0, 3)
  for (x in 1:nrow(Ped1)) {
    RCT <- rbind(RCT, rc(x, Ped1))
  }

  RCI <- matrix(NA, 0, 3)
  for (x in 1:nrow(Ped2)) {
    RCI <- rbind(RCI, rc(x, Ped2))
  }

  RCTI <- merge(as.data.frame(RCT, stringsAsFactors=FALSE),
                as.data.frame(RCI, stringsAsFactors=FALSE),
                by=c("id1", "id2"), all=TRUE, suffixes = c(".1", ".2"))
  RCTI <- RCTI[RCTI$id1 %in% Ped1$id & RCTI$id2 %in% Ped1$id &
                 RCTI$id1 %in% Ped2$id & RCTI$id2 %in% Ped2$id, ]
  RCTI$RC.1[is.na(RCTI$RC.1)] <- "U"
  RCTI$RC.2[is.na(RCTI$RC.2)] <- "U"
  RCTI$RC.1 <- factor(RCTI$RC.1, levels=c("FS", "HS", "U"))
  RCTI$RC.2 <- factor(RCTI$RC.2, levels=c("FS", "HS", "U"))

  tbl <- with(RCTI, Table(RC.1, RC.2))/2  # pairs included double
  tbl["U", "U"] <- nrow(Ped2) * (nrow(Ped2)-1)/2 - sum(tbl)
  tbl
  #  sweep(tbl, 1, rowSums(tbl), "/")
}

#============================================================================
#============================================================================

#' @title Find siblings

#' @param x  an ID
#' @param Ped  a pedigree with columns id - dam - sire
#'
#' @return The individuals which are full or half siblings to x, as a
#'   three-column matrix with column names id1 (x), id2 (the siblings), and
#'   RC (the relatedness category, 'FS' or 'HS').
#'
#' @keywords internal

rc <- function(x, Ped) {
  names(Ped) <- c("id", "dam", "sire")
  RelCat <- with(Ped,
                 ifelse(id == id[x], "S",
                        ifelse(eqv(dam[x],dam,FALSE) & eqv(sire[x], sire,FALSE), "FS",
                               ifelse(eqv(dam[x],dam,FALSE) |  eqv(sire[x], sire,FALSE), "HS",
                                      NA))))
  out <- cbind(id1 = Ped$id[x],
               id2 = Ped$id[!is.na(RelCat)],
               RC = stats::na.exclude(RelCat))
  out <- out[out[,"RC"] != "S", ]
  out
}

#============================================================================
#============================================================================
