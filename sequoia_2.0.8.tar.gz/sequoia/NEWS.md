
# sequoia 2.0.8 


### Bug fixes
- sequoia(): fixed error `object 'ErrM' not found` when re-using output from a previous sequoia run. Circumvent this bug in version 2.0.7 by fooling the program to think it's output from an older version: `names(ParOUT$Specs)[match("MaxMismatchOH", names(ParOUT$Specs))] <- "foo"`. 
- various functions: fixed error when dummy prefixes have different number of characters (`Error in data.frame(id = c(dID[s(nd[1]), 1], dID[s(nd[2]), 2]), VtoM(TMP$dumparrf,  : arguments imply differing number of rows)` )
- GetMaybeRel(): fixed error `(subscript) logical subscript too long` when input pedigree contains dummies
- GetMaybeRel(): fixed error causing likely GP pairs not to be included output


### Minor changes
- most examples are now set to `\donttest` instead of `\dontrun`, so that they can be run using `example()`. Note that some can be quite time consuming, especially `EstConf`.



# sequoia 2.0.7 

### New features
- The genotyping error matrix (probability of observed genotype conditional on actual) is now fully customisable in all relevant functions, see help file of new function `ErrToM`. The default has changed very slightly from version 1.3. 
- new function `CalcOHLLR` to calculate Mendelian errors and parental log-likelihood ratios for any pedigree
- new function `getAssignable` to flag genotyped and 'dummifiable' individuals in any pedigree
- new function `ComparePairs` to compare pairwise relationships between 2 pedigrees; replaces now-deprecated `DyadCompare`. 
- `PedPolish` is now user available.

### Major changes
- Deprecated option `MaxMismatch` of function `sequoia`, now calculated internally by new function `CalcMaxMismatch` based on number of SNPs, presumed genotyping error rate, and minor allele frequencies
- function `EstConf` now also estimates confidence for parent-pairs; output has changed considerably. 
- rewrote function `PedCompare` to increase clarity of code for easier maintenance; changed output format somewhat. 
- Added a vignette about the ageprior, and rewrote sections of the main vignette to incorporate new functions
- In the Fortran part, re-implemented how (candidate) (grand)parent-pairs are filtered and assigned 


### Bug fixes
- `GenoConvert` skipped first individual when reading .raw file. Circumvent this bug in earlier versions by using option `header=FALSE` (then header row is removed only once...)
- `ConfProb` expected input parameter `nSim` to be strictly integer, now relaxed to any value convertible to a whole number
- fixed `ERROR! ***Invalid ParProb!***` triggered when some SNPs are monomorphic
- fixed `SEGFAULT` triggered when some SNPs have very high missingness (>80%); possibly sibship size out of bounds
- fixed `Error arguments imply differing number of rows` when there are dummy parents of 1 sex only
- fixed various mostly minor bugs in the Fortran code
- fixed bugs regarding 'link time optimisation'



### Minor changes
- `LifeHistData` may have 2 additional columns, with minimum and maximum possible birth year
- second example pedigree (`Ped_griffin`) to illustrate overlapping generations, used in age vignette 
- `SummarySeq`: added a pedigree summary table identical to a subset of the table returned by R package `pedantics`' `pedStatSummary`; that package has been archived on CRAN. Added option `Panels` to only plot (a) specific panel(s).  


# Sequoia 1.3.3

### Bug fixes
- fixes bug that caused R to crash (Fortran array indexing out-of-bounds)


# Sequoia 1.3.1

### New features
- several functions have become user-visible: `CheckGeno`, `MkGenoErrors`, `GetMaybeRel`, `GetRelCat`
- plotting functions added: `PlotAgePrior` and `SummarySeq`


### Minor changes
- extended vignette with function overview & FAQ
- numerous edits to fortran source code to better handle certain (rarer) types of relatives


### Bug fixes
- various bug fixes in fortran source code


# sequoia 1.1.1

### Major changes
- possibly. 


# sequoia 1.0.0

### New features
- added functions `EstConf`, `SnpStats`

### Major changes
- considerable changes in Fortran code


# sequoia 0.9.2

### New features
- added functionality for hermaphrodites (in silico cloned into male + female)


# sequoia 0.7.2
First version on CRAN!
