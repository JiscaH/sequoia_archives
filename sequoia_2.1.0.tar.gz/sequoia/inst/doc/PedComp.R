## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE, eval=TRUE,
                      fig.height=4, fig.width=6, fig.pos="ht!") 
library(sequoia)

## ----RunPedComp---------------------------------------------------------------
library(sequoia)
data(SeqOUT_griffin, FieldMums_griffin, package="sequoia")

PCG  <- PedCompare(Ped1 = cbind(FieldMums_griffin,
                                sire = NA),
                   Ped2 = SeqOUT_griffin$Pedigree,
                   SNPd = SeqOUT_griffin$PedigreePar$id,
                   Symmetrical = TRUE)

## ----MergedPed----------------------------------------------------------------
PCG$MergedPed[c(127:133), c("id", "dam.1", "dam.2", "dam.class")]

## ----DumMatch-----------------------------------------------------------------
head(PCG$DummyMatch[, -c(3:5)], n=6)

## ----Counts-------------------------------------------------------------------
PCG$Counts[,,"dam"]

## ----Mismatch1----------------------------------------------------------------
PCG$MergedPed[which(PCG$MergedPed$dam.class == "Mismatch"), c("id", "dam.1", "dam.2", "id.dam.cat")]

## ----MisMatch1----------------------------------------------------------------
PedM <- PCG$MergedPed[, c("id", "dam.1", "dam.2")]   # short-hand to minimise typing

# does the mismatch affect all of GreenBlue's offspring?
PedM[which(PedM$dam.1 == "GreenBlue"), ]
# > yes, these 3 are all of her known offspring

# does genetic mother i081_2005_F have any field-observed offspring?
PedM[which(PedM$dam.1 == "i081_2005_F"), ]
# no.

# does i081_2005_F have any other genetic offspring?
PedM[which(PedM$dam.2 == "i081_2005_F"), ]
# yes, one non-genotyped daughter (F0015), who has no field mum 

## ----MisMatch2----------------------------------------------------------------
# why is this flagged as a mismatch?
PedM[which(PedM$dam.1 == "OrangeGreen"), ]
# all of OrangeGreen's offspring are in sibship F0003

PedM[which(PedM$dam.2 == "F0003"), c("id", "dam.1", "dam.2")]
# but sibship F0003 is split across two field mothers

## ----MisMatch3----------------------------------------------------------------
# as before
PedM[which(PedM$dam.1 == "YellowBlue"), ]
# something odd going on involving sibships F0001 & F0002

chk <- PedM[which(PedM$dam.2 %in% c("F0001", "F0002")), ]
chk[order(chk$dam.2), ]

## ----Ped1only-----------------------------------------------------------------
PCG$MergedPed[which(PCG$MergedPed$dam.class == "P1only"), 
              c("id", "id.r", "dam.1", "dam.2", "id.dam.cat")]

## ----id-idr-------------------------------------------------------------------
PCG$MergedPed[c(137,138, 6, 128,129,7), c("id", "id.r", "dam.1", "dam.2", "dam.r")]

## -----------------------------------------------------------------------------
SeqOUT_griffin$DummyIDs[c(6,7), c("id", "dam", "BY.est", "NumOff", "O1", "O2", "O3", "O4")]

