#' @title Matrix with Pairwise Relationships
#'
#' @description Generate a matrix with all pairwise relationships from a
#'   pedigree or dataframe with pairs.
#'
#' @param Pedigree  dataframe with columns id - dam - sire.
#' @param Pairs  dataframe with columns ID1 - ID2 - Rel.
#' @param GenBack  number of generations back to consider; 1 returns
#'   parent-offspring and sibling relationships, 2 also returns grand-parental,
#'   avuncular and first cousins.
#' @param patmat  logical, distinguish between paternal versus maternal relative
#'   pairs?
#'
#' @return  A square matrix, with as many rows as in \code{Pedigree} (after
#'   running \code{\link{PedPolish}}) or as many unique individuals in
#'   \code{Pairs}.
#'
#' @details  When \code{Pairs} is provided, \code{GenBack} and \code{patmat} are
#'   ignored, and no check is performed if the abbreviations are compatible with
#'   other functions.
#'
#' @seealso \code{\link{GetRelCat}}; \code{\link{ComparePairs}} for comparing
#'   pairwise relationships between two pedigrees; \code{\link{PlotRelPairs}}.
#'
#' @examples
#' data(Ped_griffin)
#' Rel.griffin <- GetRelM(Ped_griffin, patmat=TRUE, GenBack=2)
#' table(c(Rel.griffin))
#' # turning matrix into vector first makes table() much faster
#'
#' @export

GetRelM <- function(Pedigree = NULL,
                    Pairs = NULL,
                    GenBack = 1,
                    patmat = FALSE)
{
  if (!is.null(Pedigree) & !is.null(Pairs))
    stop("Please provide Pedigree or Pairs, not both")

  if (!is.null(Pedigree)) {
    Pedigree <- PedPolish(Pedigree, ZeroToNA=TRUE, NullOK=FALSE)
    RelM <- t(sapply(seq.int(nrow(Pedigree)), GetRelCat,
                     Pedigree, GenBack=GenBack, patmat=patmat))
    rownames(RelM) <- Pedigree$id

  } else if (!is.null(Pairs)) {
    if (!class(Pairs) %in% c("data.frame", "matrix"))  stop("Pairs should be a dataframe or matrix")
    Pairs <- as.data.frame(Pairs)
    names(Pairs)[1:3] <- c("ID1", "ID2", "Rel")
    for (x in 1:3)  Pairs[,x] <- as.character(Pairs[,x])

    # # valid abbreviations
    # RELS <- c("S", "M", "P", "MP", "PO", "O",
    #           "FS", "MHS", "PHS", "HS",
    #           "MGM", "MGF", "PGM", "PGF", "GP", "GO",
    #           "FA", "FN", "2nd", "HA", "HN",
    #           "DFC1", "FC1", "XX", "U", "X")
    # if (!all(Pairs$Rel %in% RELS))
    #   stop("Unknown relationship(s) in Pairs : ", setdiff(Pairs$Rel, RELS))

    RelM.tmp <- plyr::daply(Pairs, .variables=c("ID1", "ID2"), .fun=function(df) df$Rel)
    # make into symmetrical matrix to get consistency in above/below diagonal:
    IDs <- unique(c(as.character(Pairs$ID1), as.character(Pairs$ID2)))
    RelM.a <- inflate(RelM.tmp, IDs)
    RelM.b <- inflate(t(RelM.tmp), IDs)
    if(any(RelM.a != RelM.b, na.rm=TRUE)) {
      stop("One or more pairs occur 2x in 'Pairs', with different relationship")
    }
    RelM <- RelM.a
    RelM[,] <- "U"
    diag(RelM) <- "S"
    RelM[!is.na(RelM.a)] <- RelM.a[!is.na(RelM.a)]
    RelM[!is.na(RelM.b)] <- RelM.b[!is.na(RelM.b)]

  } else {
    stop("Please provide Pedigree or Pairs")
  }

  return( RelM )
}
